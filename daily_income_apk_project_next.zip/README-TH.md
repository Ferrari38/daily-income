# Daily Income – Android APK source

## Firebase project
- Project ID: `daily-income-ae661`
- Android package: `com.example.daily_income`
- `google-services.json` is included for the Android app registered in this Firebase project.
- Anonymous Authentication must be enabled.
- Firestore database and the per-user security rules have been created in Firebase Console.

## Build APK with GitHub Actions
1. Push this project to a GitHub repository you control.
2. Ensure `google-services.json` is at the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow**.
5. When the run succeeds, open its summary and download artifact `daily-income-android-apk`.
6. Extract the ZIP and install `app-release.apk` on Android.

## Local build
Install Flutter and Android SDK, then run:
```bash
flutter create --platforms=android --org com.example .
cp google-services.json android/app/google-services.json
flutter pub get
flutter build apk --release
```
The workflow configures the Google Services Gradle plugin automatically.

## App data
- Saves locally using SharedPreferences.
- Uses anonymous Firebase Authentication.
- Merges cloud history with local history at app startup.
- Syncs saved history to Firestore using one document per date.
- Offline saves remain local and can sync when online on the next save.

## Current calculation logic
- BOLT commission: 19.26%.
- Maintenance reserve: 10% of GRAB + BOLT after commission + other income.
- Total expenses: fuel + other expenses + maintenance + BOLT commission.
- Net income: GRAB + gross BOLT + other income - total expenses (tips excluded).
- Split 1: net / 2 + maintenance.
- Split 2: net / 2 + tips.

This is a starter implementation and must be built and tested before production use.
