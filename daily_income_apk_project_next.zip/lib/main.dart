import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const gold = Color(0xFFD6B56D);
const navy = Color(0xFF101827);
const boltRate = 0.1926;
const maintenanceRate = 0.10;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
    await FirebaseAuth.instance.signInAnonymously();
  } catch (_) {
    // Local mode remains available until Firebase credentials are configured.
  }
  runApp(const DailyIncomeApp());
}

class DailyIncomeApp extends StatelessWidget {
  const DailyIncomeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Daily Income',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: navy,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: gold),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFF1B2638),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        labelStyle: const TextStyle(color: Colors.white70),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
        backgroundColor: gold, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      )),
    ),
    home: const IncomeHome(),
  );
}

class IncomeEntry {
  final String date;
  final double grab, bolt, extra, tip, oil, other, startKm, endKm;
  IncomeEntry({required this.date, required this.grab, required this.bolt, required this.extra,
    required this.tip, required this.oil, required this.other, required this.startKm, required this.endKm});
  double get boltCommission => bolt * boltRate;
  double get boltAfter => bolt - boltCommission;
  double get baseBeforeMaintenance => grab + boltAfter + extra;
  double get maintenance => baseBeforeMaintenance * maintenanceRate;
  double get totalExpenses => oil + other + maintenance + boltCommission;
  double get net => grab + bolt + extra - totalExpenses; // excludes tip; follows current web-app logic
  double get firstShare => net / 2 + maintenance;
  double get secondShare => net / 2 + tip;
  double get distance => endKm - startKm;
  Map<String,dynamic> toJson() => {'date':date,'grab':grab,'bolt':bolt,'extra':extra,'tip':tip,'oil':oil,'other':other,'startKm':startKm,'endKm':endKm};
  factory IncomeEntry.fromJson(Map<String,dynamic> j) => IncomeEntry(
    date:j['date'], grab:(j['grab']??0).toDouble(), bolt:(j['bolt']??0).toDouble(),
    extra:(j['extra']??0).toDouble(), tip:(j['tip']??0).toDouble(), oil:(j['oil']??0).toDouble(),
    other:(j['other']??0).toDouble(), startKm:(j['startKm']??0).toDouble(), endKm:(j['endKm']??0).toDouble());
}

class IncomeHome extends StatefulWidget {
  const IncomeHome({super.key});
  @override State<IncomeHome> createState()=>_IncomeHomeState();
}
class _IncomeHomeState extends State<IncomeHome> {
  final fields = <String,TextEditingController>{
    for(final k in ['grab','bolt','extra','tip','oil','other','startKm','endKm']) k:TextEditingController(text:'0')
  };
  List<IncomeEntry> history=[];
  bool loading=true;
  double n(String k)=>double.tryParse(fields[k]!.text.trim())??0;
  String money(double v)=>'฿${v.toStringAsFixed(2)}';
  @override void initState(){super.initState(); load();}
  Future<void> load() async {
    final prefs=await SharedPreferences.getInstance();
    final raw=prefs.getString('driver_income_history');
    if(raw!=null) {
      history=(jsonDecode(raw) as List)
          .map((e)=>IncomeEntry.fromJson(Map<String,dynamic>.from(e))).toList();
    }
    // Merge cloud history with local history. Cloud entries with the same date win.
    final user=FirebaseAuth.instance.currentUser;
    if(user!=null) {
      try {
        final snap=await FirebaseFirestore.instance.collection('users')
            .doc(user.uid).collection('income').get();
        final merged={for(final item in history) item.date:item};
        for(final doc in snap.docs) {
          final item=IncomeEntry.fromJson(Map<String,dynamic>.from(doc.data()));
          merged[item.date]=item;
        }
        history=merged.values.toList()..sort((a,b)=>b.date.compareTo(a.date));
        await prefs.setString('driver_income_history',
            jsonEncode(history.map((e)=>e.toJson()).toList()));
      } catch (_) {
        // Keep local history available when offline or before Firestore setup.
      }
    }
    if(mounted)setState(()=>loading=false);
  }
  Future<void> persist() async {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('driver_income_history',
        jsonEncode(history.map((e)=>e.toJson()).toList()));
    final user=FirebaseAuth.instance.currentUser;
    if(user!=null) {
      try {
        final batch=FirebaseFirestore.instance.batch();
        final collection=FirebaseFirestore.instance.collection('users')
            .doc(user.uid).collection('income');
        for(final item in history) {
          batch.set(collection.doc(item.date),item.toJson());
        }
        await batch.commit();
      } catch (_) {
        // Local save succeeds even if cloud sync is temporarily unavailable.
      }
    }
  }
  IncomeEntry get current=>IncomeEntry(date:DateTime.now().toIso8601String().substring(0,10),
    grab:n('grab'),bolt:n('bolt'),extra:n('extra'),tip:n('tip'),oil:n('oil'),other:n('other'),startKm:n('startKm'),endKm:n('endKm'));
  Future<void> save() async {
    final e=current;
    history.removeWhere((x)=>x.date==e.date);
    history.add(e); history.sort((a,b)=>b.date.compareTo(a.date));
    await persist(); if(mounted)setState((){});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('บันทึกข้อมูลแล้ว')));
  }
  Widget field(String key,String label,{IconData? icon})=>Padding(
    padding:const EdgeInsets.only(bottom:12),
    child:TextField(controller:fields[key],keyboardType:const TextInputType.numberWithOptions(decimal:true),
      decoration:InputDecoration(labelText:label,prefixIcon:icon==null?null:Icon(icon,color:gold)),
      onChanged:(_)=>setState((){})));
  Widget metric(String title,double value,{bool highlight=false})=>Container(
    padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFF1B2638),borderRadius:BorderRadius.circular(14)),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(color:Colors.white60,fontSize:12)),
      const SizedBox(height:6),Text(money(value),style:TextStyle(color:highlight?gold:Colors.white,fontWeight:FontWeight.bold,fontSize:18))
    ]));
  @override Widget build(BuildContext context){
    final e=current;
    return Scaffold(appBar:AppBar(title:const Text('DAILY INCOME',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.4)),
      actions:[IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'Daily Income',applicationVersion:'1.0.0'),icon:const Icon(Icons.info_outline))]),
      body:loading?const Center(child:CircularProgressIndicator()):SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF26364D),Color(0xFF151F30)]),borderRadius:BorderRadius.circular(20),border:Border.all(color:gold.withOpacity(.45))),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('รายได้สุทธิวันนี้',style:TextStyle(color:Colors.white70)),
            const SizedBox(height:8),Text(money(e.net),style:const TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:gold)),
            const SizedBox(height:8),Text('ระยะทาง ${e.distance.toStringAsFixed(1)} กม.  •  BOLT หักคอม 19.26%',style:const TextStyle(color:Colors.white60,fontSize:12))
          ])),
        const SizedBox(height:18),
        const Text('รายได้',style:TextStyle(color:gold,fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),
        field('grab','รายได้ GRAB',icon:Icons.directions_car),
        field('bolt','รายได้ BOLT',icon:Icons.two_wheeler),
        field('extra','รายได้อื่น ๆ',icon:Icons.add_circle_outline),
        field('tip','ทิป',icon:Icons.volunteer_activism),
        const SizedBox(height:8),const Text('ค่าใช้จ่ายและระยะทาง',style:TextStyle(color:gold,fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),
        field('oil','ค่าน้ำมัน',icon:Icons.local_gas_station),
        field('other','ค่าใช้จ่ายอื่น ๆ',icon:Icons.receipt_long),
        Row(children:[Expanded(child:field('startKm','เลขไมล์เริ่มงาน')),const SizedBox(width:10),Expanded(child:field('endKm','เลขไมล์เลิกงาน'))]),
        const SizedBox(height:8),const Text('สรุปการคำนวณ',style:TextStyle(color:gold,fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),
        GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.8,children:[
          metric('คอมมิชชัน BOLT',e.boltCommission),metric('ค่าซ่อมบำรุง 10%',e.maintenance),
          metric('รายจ่ายรวม',e.totalExpenses),metric('รายได้สุทธิ',e.net,highlight:true),
          metric('ยอดแบ่งส่วนที่ 1',e.firstShare),metric('ยอดแบ่งส่วนที่ 2 + ทิป',e.secondShare,highlight:true),
        ]),
        const SizedBox(height:16),ElevatedButton.icon(onPressed:save,icon:const Icon(Icons.save),label:const Text('บันทึกรายได้วันนี้')),
        const SizedBox(height:22),const Text('ประวัติรายได้',style:TextStyle(color:gold,fontSize:17,fontWeight:FontWeight.bold)),
        if(history.isEmpty)const Padding(padding:EdgeInsets.all(16),child:Text('ยังไม่มีประวัติรายได้',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54))),
        ...history.map((h)=>Card(color:const Color(0xFF1B2638),child:ListTile(
          title:Text(h.date,style:const TextStyle(fontWeight:FontWeight.bold)),
          subtitle:Text('GRAB ${money(h.grab)} • BOLT ${money(h.bolt)} • ทิป ${money(h.tip)}'),
          trailing:Text(money(h.net),style:const TextStyle(color:gold,fontWeight:FontWeight.bold)),
          onLongPress:()async{history.remove(h);await persist();setState((){});},
        ))),
        const Padding(padding:EdgeInsets.only(top:8),child:Text('กดค้างที่รายการประวัติเพื่อลบ • ข้อมูลเก็บในเครื่อง และซิงก์ Firebase เมื่อกำหนดค่าแล้ว',style:TextStyle(color:Colors.white38,fontSize:11)))
      ])));
  }
  @override void dispose(){for(final c in fields.values){c.dispose();}super.dispose();}
}
